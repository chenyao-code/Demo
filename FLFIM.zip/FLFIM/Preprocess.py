import pickle
from models.DataSet import Itemset,ItemDataSet,ItemClient
import re

# Convert a txt file to a pickle file

data = ItemDataSet()
num = 0
# FedFIM can be used in the case where the client has multiple transactions.
# For convenience reasons, in the experiments, we assume that each client has 7 transactions.
trans_num = 7
t = 0
with open("OriginalDataset/Skin.txt", "r") as f:

    C = ItemClient()
    for line in f:
        num = num + 1
        l1 = []
        s = re.findall(r'\d+', line)
        for i in s:
            l1.append(int(i))

        x = Itemset(l1)
        C.add_line(x)
        if(num % trans_num == 0):
            t = t + 1
            data.add_line(C)
            C=ItemClient()

    if(C.data != []):
         data.add_line(C)

pickle.dump(data,open('Dataset/Skin7.pickle','wb'))

print("The total number of transactions in the dataset is: ",num)
print("Num of clients: ",t)