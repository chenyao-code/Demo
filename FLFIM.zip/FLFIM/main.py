import pickle
from sys import exit
import os
from utils.Options import args_parser
from models.Truth_Model import groundTruth
from models.FLFIM_Model import FLFIM_Model
from models.FLFIM_AES_Model import FLFIM_AES
from utils.Naming import SupportCountPickleName

from datetime import datetime

def Get_Evaluation_Results(result,truth):
    tp = 0
    for frag in result:
        if truth.count(frag)>0:
            tp += 1
    precision = tp/len(result)
    recall = tp/len(truth)
    print("Precision: %.2f; Recall: %.2f" % (precision,recall))
    print("TP: %d; FP: %d; FN: %d" % (tp,len(result)-tp,len(truth)-tp))
    F1score = (2*precision*recall)/(precision+recall)
    print("F1score: ",F1score)
    return precision, recall

def Get_True_Results(args,dataset):
    handler = groundTruth(args, dataset)
    res = handler.run()
    print('True Results : %d subsequence found' % len(res))
    scName = SupportCountPickleName(args)
    with open(scName, 'wb') as fp:
        pickle.dump(res, fp)

def GetGroundTruth(args):
    scName = SupportCountPickleName(args)
    if os.path.isfile(scName):
        with open(scName,'rb') as fp:
            sc_rec = pickle.load(fp)
            ground_truth = [i['data'] for i in sc_rec]
            return ground_truth
    print("Ground truth not generated yet")
    exit(0)

def Get_Program_Results(args):

    # Get noise results
    start_timestamp = datetime.now()

    if args.mode == 1:
        handler = FLFIM_Model(args,dataset)
    else:
        print("Execute FLFIM_ AES")
        handler = FLFIM_AES(args, dataset)

    info = handler.run()
    noise_result= [i['data'] for i in info]
    end_timestamp = datetime.now()
    time_diff = (end_timestamp - start_timestamp)
    print(f'FLFIM Time: {time_diff.total_seconds()}')

    # Get true results
    Get_True_Results(args, dataset)
    truth_result = GetGroundTruth(args)

    # Evaluate experimental results
    if len(noise_result) > 0:
        Get_Evaluation_Results(noise_result, truth_result)

    else:
        # print("No info published")
        precision = -1
        recall = -1

if __name__ == '__main__':

    args = args_parser()

    with open('Dataset/RecordLink7.pickle', 'rb') as fp:
        dataset = pickle.load(fp)

    Get_Program_Results(args)