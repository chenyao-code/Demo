'''
    Representation of trajectory and corresponding dataset in our work
'''

import numpy as np


class Itemset():
    def __init__(self,data):
        self.data = set(data)
        self.data_length = len(data)

    def checkSub(self,query):
        for i in query:
            if i not in self.data:
                return False
        return True

    def length(self):
        return len(self.data)

    def __eq__(self,other):
        comp = (self.id() == other.id())
        return comp

    def id(self):
        return tuple(list(self.data).sort())

    #def get_line(self,index):
        #return self.data[index]


class ItemClient():
    def __init__(self):
        self.data = []

    def add_line(self, line):
        self.data.append(line)

    def get_line(self, index):
        return self.data[index]

    def get_line_num(self):
        return len(self.data)

    def __getitem__(self, index):
        return self.get_line(index)


class ItemDataSet():
    def __init__(self):
        self.record = []

    def add_line(self, line):
        self.record.append(line)

    def get_line(self, index):
        return self.record[index]

    def get_line_num(self):
        return len(self.record)

    def __getitem__(self, index):
        return self.get_line(index)

    # The purpose of this function is to return the idx-th client
    def get_trajectory(self, idx):
        return self.record[idx]

    def show_dataset(self, filename):
        f = open(filename, 'a')
        for i in self.record:
            for j in i.data:
                f.write("{}".format(j))
        #f.write("{}".format(self.points))
        # print("len(self.record):", len(self.record))
