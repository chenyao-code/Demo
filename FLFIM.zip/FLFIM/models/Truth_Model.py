import math

from utils.Naming import outputNegFIN
from datetime import datetime
from math import ceil
import bitarray
class BMCTreeNode:

    def __init__(self, item, count, bitmap_code):
        self.item = item
        self.count = count
        self.bitmap_code = bitmap_code
        self.children = dict()

    def get_child_registering_item(self, item):
        return self.children.get(item)

    def add_child(self, child):
        self.children[child.item] = child

    def __repr__(self):
        return f'{self.item}:{self.count}->{self.bitmap_code}'

class FrequentItemsetTreeNode:
    def __init__(self):
        self.item = None
        self.count = 0
        self.children = []
        self.NegNodeSet = []

    def __repr__(self):
        return f'{self.item}'


def clean_BMC_tree(root):
    for item, child in root.children.items():
        clean_BMC_tree(child)
    del root.item
    del root.children

class groundTruth():
    def __init__(self,args,dataset):
        self.args = args
        self.dataset = dataset

    def run(self):
        algorithm = NegFIN(self.args,self.dataset)
        algorithm.runAlgorithm()
        # print("algorithm.FPs: ",algorithm.FPs)
        # algorithm.printStats()
        return algorithm.FPs

class NegFIN:
    def __init__(self,args,dataset):
        self.dataset = dataset
        self.min_support = args.k

        self.min_count = 0
        self.num_of_transactions = dataset.get_line_num()

        self.num_r = -1
        self.output_file = outputNegFIN(args)
        self.F1 = None
        self.item_to_NodeSet = None
        self.writer = None
        self.num_of_frequent_itemsets = 0
        self.execution_time = None
        epsilon = args.epsilon
        # candidates = args.num_candidate
        # candidates = 1
        self.eta = 1 / (1 + math.pow(math.e, epsilon))
        self.FPs = []


    def runAlgorithm(self):
        start_timestamp = datetime.now()
        self.__generate_NodeSets_of_1_itemsets()
        root = self.__create_root_of_frequent_itemset_tree()
        self.writer = open(self.output_file, 'w')
        itemset_buffer = [None] * len(self.F1)
        itemset_length = 0
        FIS_parent_buffer = [None] * len(self.F1)
        FIS_parent_length = 0
        num_of_children = len(root.children)
        for childIndex in range(num_of_children):
            child = root.children[0]
            itemset_buffer[itemset_length] = child.item
            del root.children[0]  # We delete this node since it is not used anymore.
            # Call this recursive method to traverse the search space in a depth-first order.
            self.__construct_frequent_itemset_tree(child, itemset_buffer, itemset_length + 1, root.children,
                                                   FIS_parent_buffer, FIS_parent_length)

        self.writer.close()
        end_timestamp = datetime.now()
        time_diff = (end_timestamp - start_timestamp)  # Total execution time of algorithm.
        self.execution_time = time_diff.total_seconds() * 1000


    def printStats(self):
        print('=' * 5 + 'Truthmodel - STATS' + '=' * 5)
        print(f' Minsup = {self.min_support}\n Number of transactions: {self.num_r}')
        print(f' Number of frequent  itemsets: {self.num_of_frequent_itemsets}')
        print(f' Total time ~: {self.execution_time} ms')
        #     System.out.println(' Max memory:'
        #             + MemoryLogger.getInstance().getMaxMemory() + ' MB')
        print('=' * 14)

    def __generate_NodeSets_of_1_itemsets(self):

        clientresponse = []
        item_name_to_count = {}

        self.num_r = -1
        for cid in range(self.num_of_transactions):
            for j in range(len(self.dataset.record[cid].data)):
                clientresponse.append([])
                self.num_r = self.num_r + 1
                fx = list(self.dataset.record[cid].data[j].data)
                for t in range(len(fx)):
                    clientresponse[self.num_r].append(fx[t])
                    item_count = item_name_to_count.setdefault(fx[t], 0)
                    item_name_to_count[fx[t]] = item_count + 1


        #print("self.num_r: ", self.num_r)
        self.num_r = self.num_r + 1
        # print("item_name_to_count: ", item_name_to_count)
        item_name_to_count.pop('', None)  # Removing the empty item_name if exists.
        self.min_count = ceil(self.num_r * self.min_support)
        # print("self.min_support: ",self.min_support)
        self.F1 = [{'name': item_name, 'count': item_count} for (item_name, item_count) in item_name_to_count.items() if
                   self.min_count <= item_count]
        self.F1.sort(key=lambda item: item['count'])
        self.F1 = tuple(self.F1)
        # print("F1: ",self.F1)
        item_name_to_item_index = {item['name']: item_index for (item_index, item) in enumerate(self.F1)}
        #print("item_name_to_item_index: ", item_name_to_item_index)
        self.item_to_NodeSet = {item_index: [] for item_index in item_name_to_item_index.values()}
        bmc_tree_root = BMCTreeNode(item=None, count=None, bitmap_code=bitarray.bitarray([False] * len(self.F1)))
        # x=0
        for cid in range(self.num_r):
            # x = x + 1
            transaction = [item_name_to_item_index[item_name] for item_name in clientresponse[cid] if
                           item_name in item_name_to_item_index]
            transaction.sort(reverse=True)
            #if(clientresponse[cid] != self.dataset.record[cid].data):
            #    print("nono")

            cur_root = bmc_tree_root
            for item in transaction:
                N = cur_root.get_child_registering_item(item)
                if N is None:
                    bitmap_code = cur_root.bitmap_code.copy()
                    bitmap_code[item] = True
                    N = BMCTreeNode(item=item, count=0, bitmap_code=bitmap_code)
                    cur_root.add_child(N)
                    self.item_to_NodeSet[item].append(N)

                N.count += 1
                cur_root = N
        clean_BMC_tree(bmc_tree_root)

    def __create_root_of_frequent_itemset_tree(self):
        root = FrequentItemsetTreeNode()
        for item in range(len(self.F1)):
            child = FrequentItemsetTreeNode()
            child.item = item
            child.count = self.F1[item]['count']
            child.NegNodeSet = self.item_to_NodeSet[item]
            root.children.append(child)
        return root

    def __write_itemsets_to_file(self, N, itemset_buffer, N_itemset_length, FIS_parent_buffer, FIS_parent_length):
        """
        Write the itemset represented by 'N',
         and all combination that can be made using this itemset and all subsets of FIS_parent,
         to the output file.
        Args:
            Similar to '__construct_frequent_itemset_tree'
        Returns:
            Write the discovered frequent itemset into the output file.
        """
        # Create a buffer for writing to file
        file_buffer = []

        self.num_of_frequent_itemsets += 1
        # Get the real name (string name) of items
        itemset_string = [self.F1[itemset_buffer[i]]['name'] for i in range(N_itemset_length)]
        x = itemset_string


        t = {}
        str_t = []
        for i in itemset_string:
            str_t.append(str(i))
        t['data'] = str_t
        t['support'] = N.count /self.num_r
        self.FPs.append(t)

        # Append the count of the itemset
        itemset_string.append('#SUP: {0}\n'.format(N.count))
        line = ' '.join('%s' %id for id in itemset_string)
        file_buffer.append(line)

        # === Write all combination that can be made using this itemset and all subsets of FIS_parent
        if FIS_parent_length > 0:
            # Generate all subsets of the node list except the empty set
            max = 1 << FIS_parent_length
            for i in range(1, max):
                # Get the real name of items
                itemset_string = [self.F1[itemset_buffer[i]]['name'] for i in range(N_itemset_length)]
                # We create a new subset
                # Check if the j bit is set to 1. #isSet = i & (1 << j)
                subsetString = [self.F1[FIS_parent_buffer[j]]['name'] for j in range(FIS_parent_length) if
                                (i & (1 << j)) > 0]
                # Concatenate the itemset with the subset
                itemset_string.extend(subsetString)

                t = {}
                str_t = []
                for i in itemset_string:
                    str_t.append(str(i))
                t['data'] = str_t
                t['support'] = N.count /self.num_r
                self.FPs.append(t)

                # Append the count of the itemset
                itemset_string.append('#SUP: {0}\n'.format(N.count))
                #line = ' '.join(itemset_string)
                line = ' '.join('%s' %id for id in itemset_string)
                file_buffer.append(line)

                self.num_of_frequent_itemsets += 1

        # Write the file_buffer to file and create a new line
        # so that we are ready for writing the next itemset.
        self.writer.writelines(file_buffer)
    def __construct_frequent_itemset_tree(self, N, itemset_buffer, N_itemset_length, N_right_siblings,
                                          FIS_parent_buffer,
                                          FIS_parent_length):
        for sibling in N_right_siblings:
            child = FrequentItemsetTreeNode()
            sum_of_NegNodeSets_counts = 0
            if N_itemset_length == 1:  # means at level 1
                for ni in N.NegNodeSet:
                    if not ni.bitmap_code[sibling.item]:
                        child.NegNodeSet.append(ni)
                        sum_of_NegNodeSets_counts += ni.count
            else:
                for nj in sibling.NegNodeSet:
                    if nj.bitmap_code[N.item]:
                        child.NegNodeSet.append(nj)
                        sum_of_NegNodeSets_counts += nj.count

            child.count = N.count - sum_of_NegNodeSets_counts
            if self.min_count <= child.count:
                if N.count == child.count:
                    FIS_parent_buffer[FIS_parent_length] = sibling.item
                    FIS_parent_length += 1
                else:
                    child.item = sibling.item
                    N.children.append(child)

        # Write itemset(s) to file
        self.__write_itemsets_to_file(N, itemset_buffer, N_itemset_length, FIS_parent_buffer, FIS_parent_length)

        number_of_childeren = len(N.children)
        for childIndex in range(number_of_childeren):
            child = N.children[0]
            itemset_buffer[N_itemset_length] = child.item
            del N.children[0] # We delete this node since it is not used anymore.
            self.__construct_frequent_itemset_tree(child, itemset_buffer, N_itemset_length + 1, N.children,
                                                   FIS_parent_buffer, FIS_parent_length)
