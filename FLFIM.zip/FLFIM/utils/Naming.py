def SupportCountPickleName(args):
    k = int(args.k)
    name = "Truthdata/supportcount_" + str( args.dataset) + '.pickle'
    return name

def CandidateDriftName(args):
    name = "save/candidatedrift"
    return name

def LeaveNumPickleName(args):
    name = "save/leavelog.pickle"
    return name

def outputNegFIN(args):
    name = "save/outputNegFIN.txt"
    return name