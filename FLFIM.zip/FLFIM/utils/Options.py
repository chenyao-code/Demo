import argparse

def args_parser():
    parser = argparse.ArgumentParser()
    # Basic params
    parser.add_argument('--mode', type=int, default=1, help="--mode=1 indicates execution of FedFIM, otherwise it indicates execution of FedFIM_AES")
    parser.add_argument('--k', type=float, default=0.5, help="frequency threshold")
    parser.add_argument('--xi', type=float, default=0.1, help="allowed error rate for frequency estimation")
    parser.add_argument('--epsilon', type=float, default=10.0, help="param of LDP")
    parser.add_argument('--dataset', type=str, default='msnbc', help="dataset name")
    parser.add_argument('--num_participants', type=int, default=100000, help="number of participating clients")

    args = parser.parse_args()
    return args